# import required packages


# YOUR IMPLEMENTATION
# Thoroughly comment your code to make it easy to follow


if __name__ == "__main__":
	# 1. Load your saved model

	# 2. Load your testing data

	# 3. Run prediction on the test data and output required plot and loss